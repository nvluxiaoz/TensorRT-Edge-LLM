
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_cuda_init(void **);
void _mlir_nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_cuda_load_to_device(void **);
static inline void nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_Kernel_Module_Load(nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_Kernel_Module_Unload(nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64__mlir_ciface_cutlass___call_____main__Nvfp4A16BlackwellGemmLaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_____CUstream0x0(void **args, int32_t num_args);

static inline int32_t cute_dsl_nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_wrapper(nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64_Kernel_Module_t *module, void *activation_ptr, void *qweight_ptr, void *block_scales_ptr, void *global_scale_ptr, void *output_ptr, int32_t num_tokens, int32_t out_features, int32_t in_features, int32_t max_active_clusters, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[11] = {
        &activation_ptr, &qweight_ptr, &block_scales_ptr, &global_scale_ptr, &output_ptr, &num_tokens, &out_features, &in_features, &max_active_clusters, &stream,
        &ret
    };
    _mlir_nvfp4_a16_blackwell_gemm_bf16_tm128_tn256_tk64__mlir_ciface_cutlass___call_____main__Nvfp4A16BlackwellGemmLaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_____CUstream0x0(args, 11);
    return ret;
}
