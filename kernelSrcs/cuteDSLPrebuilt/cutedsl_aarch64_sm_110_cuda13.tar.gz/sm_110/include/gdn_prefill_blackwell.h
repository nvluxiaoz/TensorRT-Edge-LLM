
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} gdn_prefill_blackwell_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_gdn_prefill_blackwell_cuda_init(void **);
void _mlir_gdn_prefill_blackwell_cuda_load_to_device(void **);
static inline void gdn_prefill_blackwell_Kernel_Module_Load(gdn_prefill_blackwell_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_gdn_prefill_blackwell_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_gdn_prefill_blackwell_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void gdn_prefill_blackwell_Kernel_Module_Unload(gdn_prefill_blackwell_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_prefill_blackwell_Tensor_q_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_prefill_blackwell_Tensor_k_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_prefill_blackwell_Tensor_v_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} gdn_prefill_blackwell_Tensor_a_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[3];
    int64_t dynamic_strides[2];
} gdn_prefill_blackwell_Tensor_b_t;


typedef struct {
    void *data;
} gdn_prefill_blackwell_Tensor_A_log_t;


typedef struct {
    void *data;
} gdn_prefill_blackwell_Tensor_dt_bias_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gdn_prefill_blackwell_Tensor_h0_in_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gdn_prefill_blackwell_Tensor_h0_out_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_prefill_blackwell_Tensor_o_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[1];
} gdn_prefill_blackwell_Tensor_cu_seqlens_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_gdn_prefill_blackwell__mlir_ciface_cutlass_run_gdn_blackwell_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemo321_Tensorgmemo321_Tensorgmemo128128i64(void **args, int32_t num_args);

static inline int32_t cute_dsl_gdn_prefill_blackwell_wrapper(gdn_prefill_blackwell_Kernel_Module_t *module, gdn_prefill_blackwell_Tensor_q_t *q, gdn_prefill_blackwell_Tensor_k_t *k, gdn_prefill_blackwell_Tensor_v_t *v, gdn_prefill_blackwell_Tensor_a_t *a, gdn_prefill_blackwell_Tensor_b_t *b, gdn_prefill_blackwell_Tensor_A_log_t *A_log, gdn_prefill_blackwell_Tensor_dt_bias_t *dt_bias, gdn_prefill_blackwell_Tensor_h0_in_t *h0_in, gdn_prefill_blackwell_Tensor_h0_out_t *h0_out, gdn_prefill_blackwell_Tensor_o_t *o, gdn_prefill_blackwell_Tensor_cu_seqlens_t *cu_seqlens, int32_t sm_count, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[14] = {
        q, k, v, a, b, A_log, dt_bias, h0_in, h0_out, o, cu_seqlens, &sm_count, &stream,
        &ret
    };
    _mlir_gdn_prefill_blackwell__mlir_ciface_cutlass_run_gdn_blackwell_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i641_Tensorgmemoi64i641_Tensorgmemo321_Tensorgmemo321_Tensorgmemo128128i64(args, 14);
    return ret;
}
