
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} gemm_blackwell_nvfp4_ws_fp16_tn256_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_gemm_blackwell_nvfp4_ws_fp16_tn256_cuda_init(void **);
void _mlir_gemm_blackwell_nvfp4_ws_fp16_tn256_cuda_load_to_device(void **);
static inline void gemm_blackwell_nvfp4_ws_fp16_tn256_Kernel_Module_Load(gemm_blackwell_nvfp4_ws_fp16_tn256_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_gemm_blackwell_nvfp4_ws_fp16_tn256_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_gemm_blackwell_nvfp4_ws_fp16_tn256_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void gemm_blackwell_nvfp4_ws_fp16_tn256_Kernel_Module_Unload(gemm_blackwell_nvfp4_ws_fp16_tn256_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C"
#endif
void _mlir_gemm_blackwell_nvfp4_ws_fp16_tn256__mlir_ciface_cutlass_wrapper___main__GemmBlackwellNvFp4WS_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_128_512_128_16__CUstream0x0(void **args, int32_t num_args);

static inline int32_t cute_dsl_gemm_blackwell_nvfp4_ws_fp16_tn256_wrapper(gemm_blackwell_nvfp4_ws_fp16_tn256_Kernel_Module_t *module, void *a_ptr, void *b_ptr, void *sfa_ptr, void *sfb_ptr, void *c_ptr, int64_t m, int64_t n, int64_t k, int32_t max_active_clusters, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[11] = {
        &a_ptr, &b_ptr, &sfa_ptr, &sfb_ptr, &c_ptr, &m, &n, &k, &max_active_clusters, &stream,
        &ret
    };
    _mlir_gemm_blackwell_nvfp4_ws_fp16_tn256__mlir_ciface_cutlass_wrapper___main__GemmBlackwellNvFp4WS_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_128_512_128_16__CUstream0x0(args, 11);
    return ret;
}
