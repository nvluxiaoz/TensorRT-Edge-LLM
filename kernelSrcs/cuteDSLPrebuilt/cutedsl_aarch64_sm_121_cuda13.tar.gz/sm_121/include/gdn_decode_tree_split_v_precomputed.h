
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} gdn_decode_tree_split_v_precomputed_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_gdn_decode_tree_split_v_precomputed_cuda_init(void **);
void _mlir_gdn_decode_tree_split_v_precomputed_cuda_load_to_device(void **);
static inline void gdn_decode_tree_split_v_precomputed_Kernel_Module_Load(gdn_decode_tree_split_v_precomputed_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_gdn_decode_tree_split_v_precomputed_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_gdn_decode_tree_split_v_precomputed_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void gdn_decode_tree_split_v_precomputed_Kernel_Module_Unload(gdn_decode_tree_split_v_precomputed_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gdn_decode_tree_split_v_precomputed_Tensor_h0_source_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_decode_tree_split_v_precomputed_Tensor_q_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_decode_tree_split_v_precomputed_Tensor_k_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_decode_tree_split_v_precomputed_Tensor_v_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_decode_tree_split_v_precomputed_Tensor_o_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[5];
    int64_t dynamic_strides[4];
} gdn_decode_tree_split_v_precomputed_Tensor_intermediate_states_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gdn_decode_tree_split_v_precomputed_Tensor_tree_parent_ids_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[2];
    int64_t dynamic_strides[1];
} gdn_decode_tree_split_v_precomputed_Tensor_tree_depths_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_decode_tree_split_v_precomputed_Tensor_qk_scales_t;


typedef struct {
    void *data;
    int32_t dynamic_shapes[4];
    int64_t dynamic_strides[3];
} gdn_decode_tree_split_v_precomputed_Tensor_gate_values_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_gdn_decode_tree_split_v_precomputed__mlir_ciface_cutlass_run_tree_split_v_precomputed_Tensorgmemo128128i64div16384163841281_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64(void **args, int32_t num_args);

static inline int32_t cute_dsl_gdn_decode_tree_split_v_precomputed_wrapper(gdn_decode_tree_split_v_precomputed_Kernel_Module_t *module, gdn_decode_tree_split_v_precomputed_Tensor_h0_source_t *h0_source, gdn_decode_tree_split_v_precomputed_Tensor_q_t *q, gdn_decode_tree_split_v_precomputed_Tensor_k_t *k, gdn_decode_tree_split_v_precomputed_Tensor_v_t *v, gdn_decode_tree_split_v_precomputed_Tensor_o_t *o, gdn_decode_tree_split_v_precomputed_Tensor_intermediate_states_t *intermediate_states, gdn_decode_tree_split_v_precomputed_Tensor_tree_parent_ids_t *tree_parent_ids, gdn_decode_tree_split_v_precomputed_Tensor_tree_depths_t *tree_depths, gdn_decode_tree_split_v_precomputed_Tensor_qk_scales_t *qk_scales, gdn_decode_tree_split_v_precomputed_Tensor_gate_values_t *gate_values, int32_t seq_len, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[13] = {
        h0_source, q, k, v, o, intermediate_states, tree_parent_ids, tree_depths, qk_scales, gate_values, &seq_len, &stream,
        &ret
    };
    _mlir_gdn_decode_tree_split_v_precomputed__mlir_ciface_cutlass_run_tree_split_v_precomputed_Tensorgmemo128128i64div16384163841281_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64i641_Tensorgmemoi64i64(args, 13);
    return ret;
}
