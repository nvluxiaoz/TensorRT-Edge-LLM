
#pragma once

#include <cuda_runtime.h>
#include <cuda_fp16.h>
#include <stdio.h>
#include <stdint.h>


// Macro to check for cuda errors.
#ifndef CUTE_DSL_CUDA_ERROR_CHECK
#define CUTE_DSL_CUDA_ERROR_CHECK(err) { \
    if ((err) != cudaSuccess) { \
        printf("Got Cuda Error %s: %s\n", cudaGetErrorName(err), cudaGetErrorString(err)); \
    } \
}

#endif

typedef struct {
    cudaLibrary_t module;
} nvfp4_fused_moe_decode_silu_m64_n128_Kernel_Module_t;

#ifdef __cplusplus
extern "C" {
#endif
void _mlir_nvfp4_fused_moe_decode_silu_m64_n128_cuda_init(void **);
void _mlir_nvfp4_fused_moe_decode_silu_m64_n128_cuda_load_to_device(void **);
static inline void nvfp4_fused_moe_decode_silu_m64_n128_Kernel_Module_Load(nvfp4_fused_moe_decode_silu_m64_n128_Kernel_Module_t *module) {
    cudaLibrary_t *libraryPtr = &(module->module);
    cudaError_t ret = cudaSuccess;
    struct {
        cudaLibrary_t **libraryPtr;
        cudaError_t *ret;
    } initArgs = {&libraryPtr, &ret};
    _mlir_nvfp4_fused_moe_decode_silu_m64_n128_cuda_init((void **)(&initArgs));
    CUTE_DSL_CUDA_ERROR_CHECK(ret);
    int32_t device_id = 0;
    struct {
        cudaLibrary_t **library;
        int32_t *device_id;
        cudaError_t *ret;
    } loadArgs = {&libraryPtr, &device_id, &ret};
    int32_t device_count;
    CUTE_DSL_CUDA_ERROR_CHECK(cudaGetDeviceCount(&device_count));
    for (int32_t i = 0; i < device_count; i++) {
        device_id = i;
        _mlir_nvfp4_fused_moe_decode_silu_m64_n128_cuda_load_to_device((void **)(&loadArgs));
        CUTE_DSL_CUDA_ERROR_CHECK(ret);
    }
}

static inline void nvfp4_fused_moe_decode_silu_m64_n128_Kernel_Module_Unload(nvfp4_fused_moe_decode_silu_m64_n128_Kernel_Module_t *module) {
    CUTE_DSL_CUDA_ERROR_CHECK(cudaLibraryUnload(module->module));
}

#ifdef __cplusplus
}
#endif

typedef struct {
    void *data;
} nvfp4_fused_moe_decode_silu_m64_n128_Tensor_barrier_count_t;


typedef struct {
    void *data;
} nvfp4_fused_moe_decode_silu_m64_n128_Tensor_barrier_epoch_t;


typedef struct {
    void *data;
} nvfp4_fused_moe_decode_silu_m64_n128_Tensor_active_expert_count_t;

#ifdef __cplusplus
extern "C"
#endif
void _mlir_nvfp4_fused_moe_decode_silu_m64_n128__mlir_ciface_cutlass___call_____main__export_decode_moe_variantlocals_DecodeMoELaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_FakeTensorInt3211_FakeTensorInt3211_Ptrg(void **args, int32_t num_args);

static inline int32_t cute_dsl_nvfp4_fused_moe_decode_silu_m64_n128_wrapper(nvfp4_fused_moe_decode_silu_m64_n128_Kernel_Module_t *module, void *a_input_ptr, void *topk_ids_ptr, void *topk_weights_ptr, void *packed_a_ptr, void *sfa_ptr, void *packed_a_storage_ptr, void *scale_storage_ptr, nvfp4_fused_moe_decode_silu_m64_n128_Tensor_barrier_count_t *barrier_count, nvfp4_fused_moe_decode_silu_m64_n128_Tensor_barrier_epoch_t *barrier_epoch, void *b_w13_ptr, void *sfb_w13_ptr, void *b_down_ptr, void *sfb_down_ptr, void *row_counts_ptr, nvfp4_fused_moe_decode_silu_m64_n128_Tensor_active_expert_count_t *active_expert_count, void *weight_expert_ids_ptr, void *global_to_local_expert_ptr, void *input_gs_ptr, void *alpha_ptr, void *down_alpha_ptr, void *global_scale_ptr, void *scatter_ptr, void *token_map_ptr, void *token_weights_ptr, int32_t num_tokens, int32_t max_rows, int32_t state_E, int32_t weight_E, int32_t rows_padded, int32_t K, int32_t N, int32_t num_topk, int32_t max_active_clusters, cudaStream_t stream) {
    int32_t ret = 0;
    void *args[35] = {
        &a_input_ptr, &topk_ids_ptr, &topk_weights_ptr, &packed_a_ptr, &sfa_ptr, &packed_a_storage_ptr, &scale_storage_ptr, barrier_count, barrier_epoch, &b_w13_ptr, &sfb_w13_ptr, &b_down_ptr, &sfb_down_ptr, &row_counts_ptr, active_expert_count, &weight_expert_ids_ptr, &global_to_local_expert_ptr, &input_gs_ptr, &alpha_ptr, &down_alpha_ptr, &global_scale_ptr, &scatter_ptr, &token_map_ptr, &token_weights_ptr, &num_tokens, &max_rows, &state_E, &weight_E, &rows_padded, &K, &N, &num_topk, &max_active_clusters, &stream,
        &ret
    };
    _mlir_nvfp4_fused_moe_decode_silu_m64_n128__mlir_ciface_cutlass___call_____main__export_decode_moe_variantlocals_DecodeMoELaunch_object_at__Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_Ptrgmem_FakeTensorInt3211_FakeTensorInt3211_Ptrg(args, 35);
    return ret;
}
